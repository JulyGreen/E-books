#!/bin/sh
swipl -f test.pl -g "[sandbox/dependencies, template/intuitivequery, template/categories]."

