#!/bin/sh
swipl -f test.pl -g "[intuitivequery, categories]."

