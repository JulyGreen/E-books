#include "a.h"
#include "lib/b.h"
#include "lib\c.h"
#include "blah.txt"

